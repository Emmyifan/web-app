module.exports = {
  publicPath: process.env.NODE_ENV === 'production'
  ?'/sites/GlobalDAS/lvc/SPDATASANDBOX/app'
  :'/',
  devServer: {
    proxy: {
      '^/sites/': {
        target: 'https://ishareteam7.na.xom.com/',
        ws: true,
        changeOrigin: true
      }
    }
  }
}